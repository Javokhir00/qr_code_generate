# import multiprocessing
# import time
#
#
# def student(number):
#     print(f"student {number} is starting...")
#     time.sleep(2)
#     print(f"student {number} is done!")
#
# if __name__ == "__main__":
#     processes = []
#     start = time.time()
#     for i in range(2):  # 2ta parallel process
#         p = multiprocessing.Process(target=student, args=(i,))
#         processes.append(p)
#         p.start()
#
#     for p in processes:
#         p.join()
#     end = time.time()
#     print("All finished.")
#     print(f"Time taken: {end - start:.2f}")
#
# # -----------------------------------------------------
#
# def number(number):
#     print(f"{number} start")
#     time.sleep(1)
#     print(f"{number} finish")
#
# if __name__ == "__main__":
#     list = []
#     start = time.time()
#     for i in range(1, 5):
#         p = multiprocessing.Process(target=number, args=(i,))
#         list.append(p)
#         p.start()
#
#     for p in list:
#         p.join()
#     end = time.time()
#     print(f"Time taken: {end - start:.4f}")

# -----------------------------------------------------------------

# def my_decorator(func):
#     def wrapper(*args, **kwargs):
#         print("starting...")
#         result = func(*args, **kwargs)
#         print("finished")
#         return result
#     return wrapper
#
# @my_decorator
# def say_hello():
#     print("sup man?")
#
# say_hello()

# ----------------------------------------------------------

# def uppercase_descriptor(func):
#     def wrapper(*args, **kwargs):
#         original = func(*args, **kwargs)
#         print(f"original text: {original}")
#         upper_text = original.upper()
#         print(f"upper text: {upper_text}")
#         return upper_text
#     return wrapper
#
# @uppercase_descriptor
# def texts():
#     return "assalomu aleykum"
#
# texts()